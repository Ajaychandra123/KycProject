from threading import *
import time
import random
import queue


def producer():
	while True:
		time.sleep(5)
		print('producer is producing')
		data=random.randint(1,10)
		print(f'producer thread produced the item :{data}')
		print('producer thraed is notifying the consumer')
		my_queue.put(data)
		time.sleep(10)

def consumer():
	while True:
		print('consumer is in waiting state')
		consumed_data=my_queue.get()
		print('consumer got notified by producer')
		print(f'consumer is consuming the item:{consumed_data}')
		print('consumer consumed the item')
		time.sleep(5)

if __name__ == '__main__':
	my_queue=queue.Queue()
	producer_thread=Thread(target=producer,name='producerthread')
	consumer_thread=Thread(target=consumer,name='consumerthread')
	consumer_thread.start()
	producer_thread.start()
