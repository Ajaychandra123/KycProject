from threading import *
import time


def producer():
	time.sleep(10)
	print('producer is producing the item')
	print('producer produced the item')
	print('producer thread notified the consumer thread')
	my_event.set()

def consumer():
	print('consumer thread is in waiting state')
	my_event.wait()
	print('consumer thread got notified by producer thread')
	print('consumer thread started to consume the item')

if __name__ == '__main__':
	my_event=Event()
	producer_thread=Thread(target=producer,name='producer')
	consumer_thread=Thread(target=consumer,name='consumer')
	producer_thread.start()
	consumer_thread.start()