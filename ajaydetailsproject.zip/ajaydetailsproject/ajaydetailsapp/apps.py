from django.apps import AppConfig


class AjaydetailsappConfig(AppConfig):
    name = 'ajaydetailsapp'
