from django.shortcuts import render

# Create your views here.

def homepage(request):
	return render(request=request, template_name="html/ajaydetailsapp/index.html")


def kyc_details(request):
	return render(request=request, template_name="html/ajaydetailsapp/kyc.html")


def marks_certificates(request):
	return render(request=request, template_name="html/ajaydetailsapp/doc.html")

